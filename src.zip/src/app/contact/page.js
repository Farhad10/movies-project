import React from 'react'

import ContactForm from '@/components/ContactForm'
const Contact = () => {
  return (
    <div className="container my-24 mx-auto md:px-6">
  
<ContactForm />
  
</div>
  )
}

export default Contact