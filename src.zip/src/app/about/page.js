import React from 'react'
import About from '@/components/About'

const page = async () => {
  
  return (
    <div className='mt-20 mb-6'>
    <About />
    </div>
    
  )
}

export default page