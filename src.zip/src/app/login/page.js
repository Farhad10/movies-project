import React from 'react'
import Login from '@/components/login'

const page = async () => {
  
  return (
    <div className='mt-20 mb-6'>
    <Login />
    </div>
    
  )
}

export default page