import React from 'react'
import Signin from '@/components/signin'

const page = async () => {
  
  return (
    <div className='mt-20 mb-6'>
    <Signin />
    </div>
    
  )
}

export default page